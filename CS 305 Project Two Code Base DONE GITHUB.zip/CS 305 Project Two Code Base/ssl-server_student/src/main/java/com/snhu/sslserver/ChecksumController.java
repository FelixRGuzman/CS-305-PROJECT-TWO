package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@RestController
public class ChecksumController {

    @GetMapping("/checksum")
    public String getChecksum() throws Exception {
        // Updated greeting per your request
        String data = "Hello, Felix Guzman! SHA-256 coming up!";
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));
        
        // Converting bytes to uppercase hex to avoid error
        
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }
        String hash = sb.toString().toUpperCase();

        // Returning our checksum!
        
        return data + " CheckSum Value: " + hash;
    }
}
